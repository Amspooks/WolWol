while (true) {
    print()
}